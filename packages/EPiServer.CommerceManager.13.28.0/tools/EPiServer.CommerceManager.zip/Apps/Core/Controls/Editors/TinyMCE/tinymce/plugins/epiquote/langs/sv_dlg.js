﻿
tinyMCE.addI18n('sv.epiquote_dlg', {
    title: "Lägg till citat",
    titleupdate: "Redigera citat",
    legendtype: "Typ av citat",
    legendinformation: "Information",
    blockquote: "Blockcitat",
    quote: "Citat",
    remove: "Ta bort",
    update: "Uppdatera",
    titlelabel: "Titel:",
    citelabel: "Cite:",
    invalidselectionforq: "HTML tillåter inte ett q-element runt vald markering."
});

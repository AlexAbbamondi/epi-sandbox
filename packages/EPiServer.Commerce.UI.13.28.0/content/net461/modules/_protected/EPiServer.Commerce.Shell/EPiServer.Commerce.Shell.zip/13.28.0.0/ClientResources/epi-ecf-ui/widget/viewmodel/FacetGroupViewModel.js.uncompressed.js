﻿define("epi-ecf-ui/widget/viewmodel/FacetGroupViewModel", [
// dojo
    "dojo/_base/declare",

    "dojo/Stateful",
    "dojo/store/Memory"
], function (
// dojo
    declare,

    Stateful,
    Memory
) {

    return declare([Stateful],
    {
        // summary:
        //      View model for "FacetGroup" widget.
        // tags:
        //      public
        id: null,

        name: "",

        collapsible: false,

        // itemsToShow: [public] bool
        //      Defines the number of items to show as default in the group.
        //      Default value is unlimited items.
        itemsToShow: 0,

        // showMatchingItems: [public] bool
        //      Indicates that show the matching items in the group.
        //      Default value is showing the matching items.
        showMatchingItems: true,

        // selectionType: [public] int
        //      Defines the facet group:
        //          0 - is single
        //          1 - is multiple
        selectionType: 0,

        // hasIcons: [public] bool
        //      Indicates that show icon for items in the group.
        //      Default value is not show icons.
        hasIcons: false,

        selection: null,

        listStore: null,

        _listStoreSetter: function (value) {
            var listStore = new Memory({ idProperty: "id" });
            listStore.setData(value || []);

            this.listStore = listStore;
        },

        getIconClasses: function (item) {
            // summary:
            //      Gets icon CSS classes for the given object.
            // item: [Object]
            //      Object to render properly icon CSS classes.
            // returns: [string]
            //      Icon CSS classes for the given object.
            // tags:
            //      public, extensions

            return this.hasIcons && item && item.iconClass;
        }
    });
});
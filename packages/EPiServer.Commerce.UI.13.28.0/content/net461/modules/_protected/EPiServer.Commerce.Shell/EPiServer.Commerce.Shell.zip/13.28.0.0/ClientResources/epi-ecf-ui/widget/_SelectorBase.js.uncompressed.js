require({cache:{
'url:epi-ecf-ui/widget/templates/_SelectorBase.html':"﻿<div class=\"dijitReset dijitInputField dijitInputContainer dijitInline epi-resourceInputContainer epi-categorySelector\" id=\"widget_${id}\">\r\n    <div data-dojo-attach-point=\"textNode\" class=\"dijit dijitReset dijitInline dijitInlineTable dijitLeft dijitTextBox epi-categoriesGroup epi-textbox-tag\">\r\n    </div>\r\n    <div data-dojo-type=\"dijit/form/Button\" data-dojo-attach-event=\"onClick: _onButtonClick\"\r\n         data-dojo-attach-point=\"button,focusNode\" data-dojo-props=\"iconClass: 'epi-iconPlus epi-icon--medium', showLabel: false\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/_SelectorBase", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/dom-construct",
// dijit
    "dijit/form/_FormValueMixin",
    "dijit/_TemplatedMixin",
    "dijit/_Widget",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/Button",
    "dijit/Tooltip",
// epi
    "epi/epi",
    "epi/shell/widget/dialog/Dialog",
// epi-cms
    "epi-cms/widget/_HasChildDialogMixin",
// epi-ecf-ui
    "./SelectorItemTag",
// resources
    "dojo/text!./templates/_SelectorBase.html"
],

function (
// dojo
    array,
    declare,
    domConstruct,
// dijit
    _FormValueMixin,
    _TemplatedMixin,
    _Widget,
    _WidgetsInTemplateMixin,
    Button,
    Tooltip,
// epi
    epi,
    Dialog,
// epi-cms
    _HasChildDialogMixin,
// epi-ecf-ui
    SelectorItemTag,
// resources
    template
) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _FormValueMixin, _HasChildDialogMixin], {
        // tags: A base class for widgets that select multiple items in a dialog.
        //      internal

        templateString: template,

        // tags:
        //    protected
        dialogTitle: null,

        // tags:
        //    protected
        placeholderText: null,

        // tags:
        //    protected
        ownDialog: true,

        // dialog: [public] epi/shell/widget/dialog/Dialog
        //      Represent the dialog which contains the tree, and will be opened when selector button is clicked.
        dialog: null,

        // tags:
        //    protected
        value: null,

        // _maxItemTagsDisplay: [protected] int
        //      Display maximum 2 item tags (in one line), if there are more selected items then append an ellipsis.
        _maxItemTagsDisplay: 2,

        // tags:
        //    protected
        _itemTagType: null,

        postCreate: function(){
            this.inherited(arguments);
            this._renderEmptyTextIfNeeded();
            this._itemTagType = this._itemTagType || SelectorItemTag;
            this.dialog = this.dialog || this._createDialog();
        },

        _setValueAttr: function (value) {
            this._internalSet(value);
        },

        _internalSet: function(value){
            // _handleOnChange will call this._set
            this._handleOnChange(value);
            this._updateTextNode(value);
        },

        compare: function (value1, value2) {
            // summary:
            //      Compare two values (as returned by get("value") for this widget).
            //      This is required by _FormValueMixin._handleOnChange.
            // tags:
            //      protected, override

            return epi.areEqual(value1, value2) ? 0 : -1;
        },

        _updateTextNode: function (value) {
            //summary:
            //    update the text node.
            //
            // value: array of selected items.
            //
            // tags:
            //    protected

            this.textNode.innerHTML = '';

            var count = 0;
            var notDisplayedItems = [];
            array.forEach(value, function (item) {
                if (count < this._maxItemTagsDisplay) {
                    this._renderItemTag(item);
                    count++;
                } else {
                    notDisplayedItems.push(item);
                }
            }, this);
            this._renderEllipsisIfNeeded(notDisplayedItems);
            this._renderEmptyTextIfNeeded();
        },

        _renderItemTag: function (item) {
            //summary:
            //    Renders a tag element for the item
            //
            // item: The item to create the tag for
            //
            // tags:
            //    protected, abstract

            var itemTag = new this._itemTagType({
                item: item
            });

            this.own(itemTag, itemTag.on("removeClick", function (item) {
                domConstruct.destroy(itemTag.id);
                itemTag.destroy();
                this._onRemoveClick(item);
                if (typeof this.focus === 'function') {
                    this.focus();
                }
            }.bind(this)));

            domConstruct.place(itemTag.domNode, this.textNode);
        },

        _renderEllipsisIfNeeded: function (notDisplayedItems) {
            if (notDisplayedItems.length === 0){
                return;
            }
            var ellipsisNode = domConstruct.create("span", { innerHTML: "..." });
            new Tooltip({
                connectId: ellipsisNode,
                label: this._getEllipsisTooltipLabel(notDisplayedItems)
            });
            domConstruct.place(ellipsisNode, this.textNode);
        },

        _getEllipsisTooltipLabel: function(notDisplayedItems) {
            //summary:
            //    Gets the tooltip label for the ellipsis node.
            //
            // notDisplayedItems: All items not already shown.
            //
            // tags:
            //    protected, abstract
        },

        _renderEmptyTextIfNeeded: function () {
            if (!this.value || this.value.length === 0) {
                domConstruct.create('div', {
                    innerHTML: this.placeholderText,
                    "class": "epi-categoriesGroup__message"
                }, this.textNode, "only");
            }
        },

        _createDialog: function() {
            var dialog = new Dialog({
                title: this.dialogTitle,
                content: this._createDialogContent(),
                dialogClass: "epi-dialog-portrait",
                destroyOnHide: false
            });

            if (!!this.ownDialog) {
                this.own(dialog);
            }

            return dialog;
        },

        _createDialogContent: function() {
            // tags:
            //    protected, abstract
        },

        _onDialogShow: function () {
            // tags:
            //    protected, abstract
        },

        _onDialogExecute: function () {
            var dialogContentValue = this._getDialogValue();
            this._internalSet(dialogContentValue);
            this._destroyHandles();
        },

        _getDialogValue: function () {
            // tags:
            //    protected, abstract
        },

        _onDialogHide: function () {
            this._destroyHandles();
        },

        _onButtonClick: function () {
            //summary:
            //    Handle the add button click
            // tags:
            //    private

            if (this.dialog) {
                this._onDialogExecuteHandle = this.connect(this.dialog, 'onExecute', '_onDialogExecute');
                this._onDialogShowHandle = this.connect(this.dialog, 'onShow', '_onDialogShow');
                this._onDialogHideHandle = this.connect(this.dialog, 'onHide', '_onDialogHide');
                this.set("isShowingChildDialog", true);
                this.dialog.show(true);
            }
        },

        _onRemoveClick: function (itemToRemove) {
            // tags:
            //    protected, abstract

            var itemIndex = -1;
            array.some(this.value, function (listEntry, index) {
                if (this._isItemEqual(itemToRemove, listEntry)) {
                    itemIndex = index;
                    return true;
                }
            }.bind(this));

            if (itemIndex === -1) {
                return;
            }

            //Here we copy the array so that everyone that holds a reference to this.value
            //will understand that this is a new value.
            var newValue = this.value.concat();
            newValue.splice(itemIndex, 1);
            this._internalSet(newValue);
        },

        _isItemEqual: function (itemToRemove, listEntry) {
            // tags:
            //    protected, abstract

            return itemToRemove === listEntry;
        },

        _destroyHandles: function () {
            this.set("isShowingChildDialog", false);
            this._onDialogExecuteHandle && this._onDialogExecuteHandle.remove();
            this._onDialogShowHandle && this._onDialogShowHandle.remove();
            this._onDialogHideHandle && this._onDialogHideHandle.remove();
        }
    });
});

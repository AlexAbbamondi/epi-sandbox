﻿define("epi-ecf-ui/component/CommerceMediaItemModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/when",
    // epi
    "epi-cms/contentediting/editors/model/CollectionEditorItemModel",
    "epi-cms/core/PermanentLinkHelper",
    // resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.commercemediacollectioneditor"
], function (
    // dojo
    declare,
    Deferred,
    when,
    // epi
    CollectionEditorItemModel,
    PermanentLinkHelper,
    // resources
    resources
) {
        return declare([CollectionEditorItemModel], {
            // summary:
            //      The commerce media item model.
            // module:
            //      "epi-ecf-ui/component/commercemediaitemmodel"
            // description:
            //      That supports: edit, delete, create commerce media link
            // tags:
            //      public

            fromItemData: function (itemData) {
                // summary:
                //      Create item model object from raw item data.
                // itemData: Object
                //      The raw item data.
                // tags:
                //      public

                if (!itemData.thumbnailUrl) {
                    itemData.assetKey = itemData.assetKey || itemData.permanentUrl || "";

                    // Store arguments so we can reuse them in another closure.
                    var args = arguments,
                        df = new Deferred();

                    when(PermanentLinkHelper.getContent(itemData.assetKey)).then(function (content) {
                        if (content) {
                            itemData.thumbnailUrl = content.thumbnailUrl;
                            itemData.assetName = content.name;
                            itemData.text = content.name;
                            itemData.assetKey = content.permanentLink;
                            itemData.assetType = itemData.assetType || content.typeIdentifier;
                        } else {
                            itemData.thumbnailUrl = itemData.assetKey;
                            itemData.assetName = resources.medianotfound;
                        }

                        //set default value for groupname and sortorder
                        itemData.groupName = itemData.groupName || "default";
                        itemData.sortOrder = itemData.sortOrder || 0;

                        // After manipulating itemData we call fromItemData on base class to set the item data property names.
                        this.inherited(args);
                        df.resolve(this);
                    }.bind(this));

                    return df;
                } else {
                    this.inherited(arguments);
                }
            }
        });
    });
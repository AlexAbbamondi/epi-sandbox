require({cache:{
'url:epi-ecf-ui/widget/templates/CampaignItemList.html':"﻿<div class=\"epi-campaign-list-container\">\r\n    <!-- the toolbar is only here to be able to resize without exceptions -->\r\n    <div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"dijit/_WidgetBase\" style=\"display:none\"></div>\r\n    <div class=\"epi-editor-overlay\" data-dojo-attach-point=\"overlayDnd\">\r\n        <div data-dojo-attach-point=\"gridNode\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/CampaignItemList", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/event",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-class",
    "dojo/Deferred",
    "dojo/html",
    "dojo/keys",
    "dojo/query",
    "dojo/when",
    // epi
    "epi",
    "epi/dependency",
    "epi/shell/command/builder/ButtonBuilder",
    // commerce
    "./viewmodel/CampaignItemListModel",
    "./_MarketingListBase",
    "./_ToggleCutSelectionMixin",
    "../contentediting/editors/_CollectionEditorDndMixin",
    "../MarketingUtils",
    // resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "dojo/text!./templates/CampaignItemList.html"
], function (
    // dojo
    declare,
    event,
    lang,
    aspect,
    domClass,
    Deferred,
    html,
    keys,
    query,
    when,
    // epi
    epi,
    dependency,
    ButtonBuilder,
    // commerce
    CampaignItemListModel,
    _MarketingListBase,
    _ToggleCutSelectionMixin,
    _CollectionEditorDndMixin,
    MarketingUtils,
    // resources
    resources,
    template
) {
        return declare([_MarketingListBase, _ToggleCutSelectionMixin, _CollectionEditorDndMixin], {
            templateString: template,

            typeIdentifiers: [
                MarketingUtils.contentTypeIdentifier.salesCampaign,
                MarketingUtils.contentTypeIdentifier.promotionData
            ],

            withDeleteButton: false,

            postMixInProperties: function () {
                this._facetFiltersService = this._facetFiltersService || dependency.resolve("epi.commerce.FacetFiltersService");
                this.inherited(arguments);

                lang.mixin(this.defaultGridMixin.dndParams, {
                    selfAccept: true,
                    copyOnly: false,
                    accept: [MarketingUtils.contentTypeIdentifier.promotionData]
                });
            },

            buildRendering: function () {
                // summary:
                //		Construct the UI for this widget with this.domNode initialized as a dgrid.
                // tags:
                //		protected

                this.inherited(arguments);

                this._modifyStoreToHandleDgridTree();
            },

            postCreate: function () {
                // tags:
                //      extensions

                this.inherited(arguments);

                domClass.add(this.grid.domNode, "epi-campaign-list");

                this.own(
                    this._viewModel,
                    this._viewModel.on("pasteComplete", function (itemId) {
                        this.grid && this.grid.refresh();
                        this._pastedItemId = itemId;
                        this.emit("campaignListUpdate");
                    }.bind(this)),
                    this._viewModel.on("updateSelection", function (itemId) {
                        this.grid && this.grid.refresh();
                    }.bind(this)),
                    this.grid.on("dgrid-deselect", this.updateSelection.bind(this))
                );

                this._setupDnD();
            },

            startup: function () {
                // tags:
                //      extensions

                this.inherited(arguments);

                var dndSource = this.grid.dndSource;
                dndSource.allowNested = true;

                this.own(aspect.after(dndSource, "onDndStart", this._onDndStart.bind(this), true));
            },

            setupEvents: function () {
                this.inherited(arguments);
                this.grid.addKeyHandler(keys.DELETE, function (e) {
                    var row = this.grid.row(e);
                    var deleteCommand = this.model.createDeleteCommand();
                    deleteCommand.set("model", row.data);
                    deleteCommand.execute();
                }.bind(this));
                this._setupOnStoreItemDeleted();
            },

            onContextMenuClick: function (e) {
                this.inherited(arguments);
                var row = this.grid.row(e);
                this.model.updateCommandModel(lang.mixin(row.data, { rowId: row.id }));
            },

            getQuery: function (parentId, excludeFacets) {
                return {
                    query: this.queryName,
                    referenceId: parentId,
                    typeIdentifiers: this.typeIdentifiers,
                    campaignFacets: excludeFacets ? "{}" : this._facetFiltersService.getFiltersAsJson()
                };
            },

            createModel: function () {
                return this._viewModel = this._viewModel || new CampaignItemListModel({
                    store: this.store
                });
            },

            getListSettings: function () {
                var settings = this.inherited(arguments);
                if (this.withDeleteButton) {
                    this._replaceContextMenuByDeleteButton(settings.columns);
                }

                var self = this;
                return lang.mixin(this.defaultGridMixin, lang.mixin(settings, {
                    showHeader: false,
                    renderArray: function () {
                        return when(this.inherited(arguments), function (results) {
                            //After calling the inherited renderArray function we clear the noDataNode.
                            //This forces the grid to create a new node every time a campaign does not have any promotion.
                            self.grid.noDataNode = null;

                            if (results.length > 0) {
                                var contentLinks = [], shouldUpdateRedemptions = true;
                                for (var i = 0, length = results.length; i < length; i++) {
                                    var row = self.grid.row(results[i]),
                                        itemData = row.data;
                                    if (itemData.contentLink === self._pastedItemId) {
                                        self.grid.select(row);
                                        self.grid.focus(row.element);
                                    }
                                    contentLinks.push(itemData.contentLink);
                                    shouldUpdateRedemptions &= MarketingUtils.isPromotionData(itemData.typeIdentifier);
                                }
                                self._updateOrderCounts(contentLinks);
                                if (shouldUpdateRedemptions) {
                                    self._updateRedemptions(contentLinks);
                                }
                            }

                            return results;
                        });
                    },
                    onContextMenuClick: function (e) {
                        this.inherited(arguments);
                        self.onContextMenuClick(e);
                    }
                }));
            },

            updateSelection: function () {
                var selection = [];
                for (var id in this.grid.selection) {
                    var row = this.grid.row(id);
                    selection.push(lang.mixin(row.data, { rowId: id }));
                }

                this.model.updateSelection(selection);
            },

            _onDndStart: function (source, nodes) {
                var accepted = this.grid.dndSource.accept && this.grid.dndSource.checkAcceptance(source, nodes);
                domClass.toggle(this.overlayDnd, "epi-grid-dnd-overlay", accepted);
            },

            _onSelect: function (e) {
                // tags:
                //		protected extensions

                this.inherited(arguments);

                this.updateSelection();
            },

            _updateOrderCounts: function (contentLinks) {
                // summary:
                //      Updates order count statistic for each campaign.
                // contentLinks: [Array]
                //      Collection of campaign/promotion link.
                // tags:
                //      private

                var gridId = this.grid.id;
                when(this.model.getOrderCounts(contentLinks), function (results) {
                    if (!(results instanceof Array) || results.length === 0) {
                        return;
                    }

                    for (var i = 0, length = results.length; i < length; i++) {
                        var orderCountNode = query("#" + gridId + "-row-" + results[i].contentLink + " .field-ordertotal .epi-primaryText")[0];
                        orderCountNode && html.set(orderCountNode, results[i].orderCount.toString());
                    }
                });
            },

            _updateRedemptions: function (promotionLinks) {
                // summary:
                //      Updates redemptions for each promotion.
                // promotionLinks: [Array]
                //      Collection of promotion link.
                // tags:
                //      private

                var gridId = this.grid.id;
                when(this.model.getRedemptions(promotionLinks), function (results) {
                    if (!(results instanceof Array) || results.length === 0) {
                        return;
                    }

                    for (var i = 0, length = results.length; i < length; i++) {
                        var redemptionNode = query("#" + gridId + "-row-" + results[i].contentLink + " .field-redemptions .epi-primaryText")[0];
                        redemptionNode && html.set(redemptionNode, results[i].totalRedemptions.toString());
                    }
                });
            },

            _modifyStoreToHandleDgridTree: function () {
                // summary:
                //      getChildren and mayHaveChildren are needed on the store
                //      for dgrids tree module to work.
                // tags:
                //      private
                var self = this;
                this.store = lang.mixin(this.store, {
                    getChildren: function (parent, options) {
                        return this.query(self.getQuery(parent.contentLink), options);
                    },
                    mayHaveChildren: function (parent) {
                        // only campaigns have children
                        return MarketingUtils.isSalesCampaign(parent.typeIdentifier);
                    }
                });
            },

            _replaceContextMenuByDeleteButton: function (columnSettings) {
                columnSettings = lang.mixin(columnSettings, {
                    contextMenu: {
                        renderHeaderCell: function () { }, // no header
                        renderCell: function (object, value, node, options) {
                            var deleteCommand = this.model.createDeleteCommand(false);
                            var builder = new ButtonBuilder({
                                settings: {
                                    showLabel: false,
                                    "class": "epi-chromeless",
                                    onKeyDown: function (e) {
                                        if (e.keyCode === keys.ENTER) {
                                            //when pressing ENTER on button we need to stop the grids key handler changing context.
                                            event.stop(e);
                                        }
                                    }
                                }
                            });
                            deleteCommand.set("model", object);
                            builder.create(deleteCommand, node);
                        }.bind(this),
                        className: "epi-columnNarrow",
                        sortable: false
                    }
                });
            },

            _setupOnStoreItemDeleted: function () {
                if (epi.isEmpty(this.store) || typeof this.store.on !== "function") {
                    return;
                }

                this.own(
                    this.store.on("delete", function (deletedItem) {
                        var deleted = !!(deletedItem && deletedItem.id);
                        if (deleted) {
                            this.model.set("deletedItemId", deletedItem.id);
                            this.grid && this.grid.refresh();
                        }
                    }.bind(this))
                );
            }
        });
    });